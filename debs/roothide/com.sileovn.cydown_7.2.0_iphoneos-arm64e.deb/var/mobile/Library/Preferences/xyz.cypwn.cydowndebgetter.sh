#!/var/jb/usr/bin/bash

## .deb retriever and jumper for Cydown++, Erika, and Debra
## Works for downloads with md5 error or just for organizing all downloads, placing all debs into 1 location: CyDown folder

cydwndir=/var/mobile/Documents/CyDown
cydiadir=/var/mobile/Library/Caches/com.saurik.Cydia/archives/partial
debradir=/var/mobile/Documents/Debra/repackedDebs
erikadir=/var/mobile/Erika
instldir=/var/mobile/Library/'Application Support'/Installer/APT/archives/partial
sailydir=/var/mobile/Documents/wiki.qaq.chromatic/Downloads
zebradir=/var/mobile/Library/'Application Support'/xyz.willy.Zebra/debs/partial
cydia2dir=/var/jb/var/mobile/Library/Caches/com.saurik.Cydia/archives/partial
instl2dir=/var/jb/var/mobile/Library/'Application Support'/Installer/APT/archives/partial
zebra2dir=/var/jb/var/mobile/Library/'Application Support'/xyz.willy.Zebra/debs/partial

mv=/var/jb/usr/bin/mv
mkdir=/var/jb/usr/bin/mkdir
ls=/var/jb/usr/bin/ls
sed=/var/jb/usr/bin/sed
ctf=/var/jb/usr/local/bin/ctf
echo=/var/jb/usr/bin/echo
cat=/var/jb/usr/bin/cat
tail=/var/jb/usr/bin/tail

for fspec1 in "${cydiadir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${debradir}"/*_iphoneos-arm.deb; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${erikadir}"/*_iphoneos-arm.deb; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${instldir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${sailydir}"/*_iphoneos-arm.deb; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${zebradir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${cydia2dir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${instl2dir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done
for fspec1 in "${zebra2dir}"/*_iphoneos-arm.deb.*; do
  fspec2=$($echo "${fspec1}" | $sed 's/_iphoneos-arm.deb.*/.deb/')
  $mv "${fspec1}" "${fspec2}" 2> /dev/null
done

$mkdir "${cydwndir}" 2> /dev/null
$mv "${cydiadir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${debradir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${erikadir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${instldir}"/*.deb "${cydwndir}" 2> /dev/null
#$mv "${sailydir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${zebradir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${cydia2dir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${instl2dir}"/*.deb "${cydwndir}" 2> /dev/null
$mv "${zebra2dir}"/*.deb "${cydwndir}" 2> /dev/null
mrecent=$($ls "${cydwndir}"/*.deb -Art | $tail -n 1)

if [ -f  "${mrecent}" ]; then
  $ctf "${mrecent}"
else
  $ctf "${cydwndir}"
fi

$cat << "EOF"
 
Done! You may close this.
 
Latest .deb highlighted in CyDown Folder!
 
 
╭━╮ ╭━╮
┃╭╋┳┫╋┣┳┳┳━┳╮
┃╰┫┃┃╭┫┃┃┃┃┃┃
╰━╋╮┣╯╰━━┻┻━╯
  ╰━╯
 
 
EOF